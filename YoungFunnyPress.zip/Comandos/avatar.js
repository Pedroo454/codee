module.exports = {
    name: "avatar",
    code: `
  $author[$username's Avatar!]
  $color[Random]
  $image[$authorAvatar]
  $footer[Requested by $username]
  $addTimestamp
  `
};