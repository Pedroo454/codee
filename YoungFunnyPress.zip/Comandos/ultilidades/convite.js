module.exports = ({
    name: "convite",
    aliases: ['myadd', 'invite'],
    code: `
    $title[ __*Convite - Bot*__]
    $description[ (📬 ) - [Suporte\](https://discord.gg/DChb5NeceK)
( 📧 ) - [Invite\](https://discord.gg/DChb5NeceK)]
    $getGuildVar[oiiia]
   ]
    $image[https://media.discordapp.net/attachments/1097591338221973520/1287170665601957929/standard.gif?ex=66f13b59&is=66efe9d9&hm=53279543d08aa0be6aaf957a639548bd764fd6b9657a8dd8a9662df8a7e8b969&=]
    $footer[Ultilizador: $username;$userAvatar]
    $addbutton[1;Suporte;link;https://discord.gg/DChb5NeceK]
    $addbutton[1;Invite Bot;link;https://discord.gg/DChb5NeceK]
    `
});