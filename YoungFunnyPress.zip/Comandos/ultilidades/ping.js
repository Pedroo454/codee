module.exports = ({
    name: "ping",
    aliases: ['pingar', 'pong'],
    code: `
    $description[🏓  | **Pong**! Meu ping é de \`$pingms\` ]
    $footer[Ultilizador: $username;$userAvatar]
    $color[Random]
    `
})