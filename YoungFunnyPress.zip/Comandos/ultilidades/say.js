module.exports = ({
  name: "say",
  aliases: ['Escrever', 'write'],
  usage: "t!clear <Numero de mensagens>",
  code:`
 $onlyIf[$noMentionMessage>0;{newEmbed: {title:Minimo de copia }{description:Minimo um}{color:Red}}]

$argsCheck[>0;{newEmbed: {title:Invalid Arguments}{description:t!purge 10}{color:Red}}}]

  $description[$message]
  $footer[Ultilizador: $username;$userAvatar]
  `

});