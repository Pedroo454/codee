module.exports = [{
name: "clear",
aliases: ['limpar', 'apagar'],
usage: "t!clear <Numero de mensagens> #canal(opcional)",
code: `
$username Apagou $noMentionMessage Mensagens em <#$mentionedChannels[1;true]>


$clear[$channelID;$noMentionMessage;false;false;true]
$onlyIf[$noMentionMessage<=100;{newEmbed: {title:Error}{description: Não é possível limpar mais de 100 mensagens!}{color:Red}}]

$onlyIf[$noMentionMessage>0;{newEmbed: {title:Minimo de mensagens }{description:Minimo um}{color:Red}}]

$onlyIf[$isNumber[$noMentionMessage]!=false;{newEmbed: {title:Not A Valid Numbers}{description:Please type a valid numbers!}{color:Red}}}]

$argsCheck[>0;{newEmbed: {title:Invalid Arguments}{description:t!purge 10}{color:Red}}}]

$onlyClientPerms[managemessages;{newEmbed:{title:Missing Permission}{description:In this command I'm require to have "Manage Messages" permission to do that.}{color:Red}}]

$onlyPerms[managemessages;{newEmbed:{title:Missing Permission}{description:This command user are required to have "Manage Messages" permission to be execute.}{color:Red}}]`
}]