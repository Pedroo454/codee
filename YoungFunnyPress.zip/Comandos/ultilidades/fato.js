module.exports = ({
  name: "fato",
  aliases: ['aleatorio', 'random'],
  code: `
  $title[**FATO ALEATÓRIO**]
  $description[
  $randomText[A Escócia tem 421 palavras diferentes para neve.;A chance de você morrer no caminho para conseguir bilhetes de loteria é na verdade maior do que a sua chance de ganhar.;Um homem da Grã-Bretanha mudou seu nome para Tim Pppppppppprice para dificultar a pronúncia dos operadores de telemarketing.;Você respira em média cerca de 8.409.600 vezes por ano;Para produzir 450 g de mel, uma única abelha teria que visitar 2 milhões de flores.;Se você tentar suprimir um espirro, poderá romper um vaso sanguíneo na sua cabeça ou pescoço e morrer.;Os abacates são venenosos para os pássaros.;O ketchup era usado como medicamento na década de 1930.;A goma de mascar queima cerca de 11 calorias por hora.;Cada carro de polícia holandês tem um ursinho de pelúcia.;Homens têm 6 vezes mais probabilidade de serem atingidos por raios do que mulheres.;Antigamente, as cenouras eram roxas e não laranjas.;O coração de um camarão está localizado em sua cabeça.;Em média, uma pessoa passa 6 meses de sua vida parada no semáforo, esperando a luz vermelha ficar verde.;A Terra está repleta de vírus. Existem cerca de dez nonilhões de vírus (10 elevado a 31) no planeta, e isso é mais que as estrelas do universo.;A maior abóbora do mundo pesa mais do que um carro esportivo.;Uma cervejaria no Canadá fabrica cerveja usando água de icebergs de 20.000 anos.;As baratas existem há 120 milhões de anos, antes mesmo dos dinossauros vagarem pela Terra.;Em média, uma pessoa anda o equivalente a três vezes ao redor do mundo na vida.;Quando criança, Adolf Hilter queria ser padre. Ele também sofria de Ailurofobia, que é o medo de gatos.;2]]
  $footer[Ultilizador: $username;$userAvatar]
  $color[Random]
  `

});