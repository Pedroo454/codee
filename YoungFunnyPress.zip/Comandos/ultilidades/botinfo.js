module.exports = ({
    name: "botinfo",
    aliases: ['botdados', 'infobot'],
    code: `
    $title[ __*Bot & Info*__]
    $description[
    ( 👑 ) - Meu criador: **Pedrinho.pkz**
    ( 🍀 ) - Nome: **TesteBot**
    ( **#** ) - Tag: **#2993**
    ( 🆔 ) - Bot ID: 
    ( 📅 ) - Criado: **27 de Setembro de 2024**
    ( 👨‍💻 ) - Feito em: **Aoi.js**
    ( :flag_br:  ) - Linguagem: PT/BR
    ( 📌 ) - Prefixo: **A?**
    ( ⏱ ) - Uptime: $uptime[full]
    ( ⚙ ) - Versão: **1.0.0** ]
    $thumbnail[$userAvatar[$clientID]]
    $image[https://media.discordapp.net/attachments/1097591338221973520/1287170665601957929/standard.gif?ex=66f13b59&is=66efe9d9&hm=53279543d08aa0be6aaf957a639548bd764fd6b9657a8dd8a9662df8a7e8b969&=]
    $footer[Ultilizador: $username;$userAvatar]
    $addbutton[1;Suporte;link;https://discord.gg/DChb5NeceK]
    $addbutton[1;Invite Bot;link;https://discord.gg/DChb5NeceK]
    `
});